console.log("Sqwert Mod carregado: New Mobs 🐑🦊👾");

(function() {
  if (!window.GameAPI || !GameAPI.scene) {
    console.error("GameAPI não disponível ainda!");
    return;
  }

  const loader = new THREE.TextureLoader();

  // Lista de mobs com texturas locais
  const mobs = [
    {
      name: "Sheep",
      texture: "assets/textures/ovelha.png",
      size: [0.9, 0.9, 0.9],
      pos: [4, 0.5, -4]
    },
    {
      name: "Fox",
      texture: "assets/textures/raposa.png",
      size: [0.8, 0.8, 0.8],
      pos: [-4, 0.5, 4]
    },
    {
      name: "Slime",
      texture: "assets/textures/slime.png",
      size: [1.2, 1.2, 1.2],
      pos: [0, 0.5, 6]
    }
  ];

  // Função para spawnar mobs
  function spawnMob(mobData) {
    loader.load(mobData.texture, tex => {
      const geo = new THREE.BoxGeometry(...mobData.size);
      const mat = new THREE.MeshBasicMaterial({ map: tex });
      const mob = new THREE.Mesh(geo, mat);

      mob.position.set(...mobData.pos);
      mob.name = mobData.name;

      GameAPI.scene.add(mob);

      // Animação bobbing simples
      let up = true;
      setInterval(() => {
        mob.position.y += up ? 0.03 : -0.03;
        if (mob.position.y > 1) up = false;
        if (mob.position.y < 0.5) up = true;
      }, 150);

      console.log(`Mob spawnado: ${mobData.name}`);
    },
    undefined,
    err => {
      console.error(`Erro ao carregar textura de ${mobData.name}:`, err);
    });
  }

  // Spawnar todos os mobs
  mobs.forEach(spawnMob);

})();
